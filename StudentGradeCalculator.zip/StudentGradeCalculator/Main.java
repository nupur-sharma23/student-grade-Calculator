import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        Student[] students = new Student[n];

        double totalAverage = 0;

        for (int i = 0; i < n; i++) {

            System.out.println("\nEnter Details of Student " + (i + 1));

            sc.nextLine();

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Student ID: ");
            int id = sc.nextInt();

            System.out.print("Enter Number of Grades: ");
            int size = sc.nextInt();

            int[] grades = new int[size];

            for (int j = 0; j < size; j++) {
                System.out.print("Enter Grade " + (j + 1) + ": ");
                grades[j] = sc.nextInt();
            }

            students[i] = new Student(name, id, grades);

            totalAverage += students[i].calculateAverage();
        }

        System.out.println("\n===== STUDENT REPORT =====");

        for (int i = 0; i < n; i++) {
            students[i].displayStudentInfo();
        }

        double classAverage = totalAverage / n;

        System.out.println("\nClass Average: " + classAverage);

        sc.close();
    }
}
