# Student Grade Calculator

## Description

Student Grade Calculator is a Java-based application that manages multiple students and their grades. The program calculates individual student averages, determines pass/fail status, and computes the overall class average using Object-Oriented Programming concepts.

## Features

* Store student name and ID
* Store multiple grades for each student
* Calculate average grade
* Display individual grades
* Determine pass/fail status
* Manage multiple students
* Calculate overall class average

## Technologies Used

* Java
* Object-Oriented Programming (OOP)

## Project Structure

StudentGradeCalculator/

├── Student.java

└── Main.java

## How to Run

Compile the project:

javac Student.java Main.java

Run the project:

java Main

## Sample Output

Enter number of students: 2

Name: Pritam

Student ID: 101

Grades: 80 90 70

Average Grade: 80.0

Result: PASS

Class Average: 65.0

## Author

Nupur Sharma
