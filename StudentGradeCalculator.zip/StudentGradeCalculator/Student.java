public class Student {

    String name;
    int studentId;
    int[] grades;

    Student(String name, int studentId, int[] grades) {
        this.name = name;
        this.studentId = studentId;
        this.grades = grades;
    }

    double calculateAverage() {
        int sum = 0;

        for (int i = 0; i < grades.length; i++) {
            sum += grades[i];
        }

        return (double) sum / grades.length;
    }

    void displayGrades() {
        System.out.print("Grades: ");

        for (int i = 0; i < grades.length; i++) {
            System.out.print(grades[i] + " ");
        }

        System.out.println();
    }

    String getResult() {
        if (calculateAverage() >= 40) {
            return "PASS";
        } else {
            return "FAIL";
        }
    }

    void displayStudentInfo() {
        System.out.println("\nName: " + name);
        System.out.println("Student ID: " + studentId);

        displayGrades();

        System.out.println("Average Grade: " + calculateAverage());
        System.out.println("Result: " + getResult());
    }
}